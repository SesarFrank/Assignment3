import java.io.IOException;

import java.util.*;
import org.jsoup.Jsoup;
import java.io.*;
import java.net.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main2014302580304 {  
    ArrayList<String> allurlSet = new ArrayList<String>();
    ArrayList<String> notCrawlurlSet = new ArrayList<String>();
    HashMap<String, Integer> depth = new HashMap<String, Integer>();
    int crawDepth  = 2; //�������  
    int threadCount = 10; //�߳�����  
    int count = 0; //��ʾ�ж��ٸ��̴߳���wait״̬  
    public static final Object signal = new Object();   //�̼߳�ͨ�ű���  
      
    public static void main(String[] args) {  
        final Main2014302580304 wc = new Main2014302580304();  
        wc.addUrl("http://cs.whu.edu.cn/plus/list.php?tid=36", 1);  
        long start= System.currentTimeMillis();  
        System.out.println("��ʼ����.........................................");  
        wc.begin();  
          
        while(true){  
            if(wc.notCrawlurlSet.isEmpty()&& Thread.activeCount() == 1||wc.count==wc.threadCount){  
                long end = System.currentTimeMillis();  
                System.out.println("�ܹ�����"+wc.allurlSet.size()+"����ҳ");  
                System.out.println("�ܹ���ʱ"+(end-start)/1000+"��");  
                System.exit(1);  
            }  
              
        }  
    }  
    private void begin() {  
        for(int i=0;i<threadCount;i++){  
            new Thread(new Runnable(){  
                public void run() {  
                    while (true) {   
                        String tmp = getAUrl();  
                        if(tmp!=null){  
                            crawler(tmp);  
                        }else{  
                           synchronized(signal) {
                                try {  
                                    count++;  
                                    System.out.println("��ǰ��"+count+"���߳��ڵȴ�");  
                                    signal.wait();  
                                } catch (InterruptedException e) {  
                                    // TODO Auto-generated catch block  
                                    e.printStackTrace();  
                                }  
                            }  
                              
                              
                        }  
                    }  
                }  
            },"thread-"+i).start();  
        }  
    }  
    public synchronized  String getAUrl() {  
        if(notCrawlurlSet.isEmpty())  
            return null;  
        String tmpAUrl;   
            tmpAUrl= notCrawlurlSet.get(0);  
            notCrawlurlSet.remove(0);  
        return tmpAUrl;  
    }  

      
    public synchronized void  addUrl(String url,int d){  
            notCrawlurlSet.add(url);  
            allurlSet.add(url);  
            depth.put(url, d);  
    }  
      
    
    public  void crawler(String sUrl){  
        URL url;  
        try {  
                url = new URL(sUrl);  
                URLConnection urlconnection = url.openConnection();  
                urlconnection.addRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");  
                InputStream is = url.openStream();  
                BufferedReader bReader = new BufferedReader(new InputStreamReader(is));  
                StringBuffer sb = new StringBuffer();
                String rLine = null;  
                while((rLine=bReader.readLine())!=null){  
                    sb.append(rLine);  
                    sb.append("/r/n");  
                }  
                  
                int d = depth.get(sUrl);  
                System.out.println("����ҳ"+sUrl+"�ɹ������Ϊ"+d+" �����߳�"+Thread.currentThread().getName()+"����");  
                if(d<crawDepth){  
                    parseContext(sb.toString(),d+1);  
                }  

  
              
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
    }  
  
    public  void parseContext(String context,int dep) {  
        String regex = "<a href.*?/a>";  
        String s = "<a href='http://cs.whu.edu.cn/'>ѧԺ��ҳ</a> > <a href='/plus/list.php?tid=36'>��ʦ��¼</a> >";  
        Pattern pt = Pattern.compile(regex);  
        Matcher mt = pt.matcher(context);  
        while (mt.find()) {  
            Matcher myurl = Pattern.compile("href=\".*?\"").matcher(  
                    mt.group());  
            while(myurl.find()){  
                String str = myurl.group().replaceAll("href=\"|\"", "");    
                if(str.contains("http:")){ 
                    if(!allurlSet.contains(str)){  
                        addUrl(str, dep);
                        if(count>0){ 
                            synchronized(signal) {
                                count--;  
                                signal.notify();  
                            }  
                        }  
                          
                    }  
                }  
            }  
        }  
    }  
}     
